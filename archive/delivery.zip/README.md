# Delivery Network Data README

本说明对应脚本 `delivery_network_all_in_one.sql`，用于初始化 `csc3170` 数据库中的 Delivery Network 子集数据。

## 1. 覆盖范围
- 实体表：`rider`、`delivery_task`
- 关系：`execute`（`delivery_task.rider_id -> rider.rider_id`）
- 不包含 ER 图其他模块，不包含 `assigned` 关系实现。

## 2. 数据规模
- rider：200 条
- delivery_task：500 条

## 3. 字段说明
### rider
- `rider_id`：5 位字符串主键（`00001` ~ `00200`）
- `real_name`：骑手姓名（模拟）
- `phone`：手机号（模拟）
- `status`：骑手状态（`available` / `busy` / `offline`）
- `rating`：评分（`DECIMAL(2,1)`）
- `affiliation_type`：用工类型（`full_time` / `part_time` / `outsourced`）

### delivery_task
- `task_id`：5 位字符串主键（`00001` ~ `00500`）
- `rider_id`：外键，引用 `rider.rider_id`
- `task_status`：任务状态（`pending` / `assigned` / `picked_up` / `delivering` / `completed` / `cancelled`）

## 4. 当前数据分布（快照）
### rider.status
- available: 61
- busy: 65
- offline: 74

### delivery_task.task_status
- pending: 74
- assigned: 108
- picked_up: 85
- delivering: 61
- completed: 93
- cancelled: 79

## 5. 执行行为
脚本执行时会：
1. `CREATE DATABASE IF NOT EXISTS csc3170` 并 `USE csc3170`
2. `CREATE TABLE IF NOT EXISTS` 创建两张表
3. 在事务中先清空数据：`DELETE FROM delivery_task; DELETE FROM rider;`
4. 再插入本文件定义的初始化数据

因此该脚本适合“重置并重新灌入演示数据”的场景。